# Generate-Random-Numbers

To understand the code, watch this video : https://youtu.be/7zlVvtcMceU
